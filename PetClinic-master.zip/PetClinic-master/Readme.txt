#readme.txt file.
Updated
Added line to auto trigger jenkins job

Added a line to trigger the job again

Added a line to trigger the job again

